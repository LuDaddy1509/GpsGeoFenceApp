namespace SmartTour.Mobile.Models;

public sealed class PlaybackLogEnvelope
{
    public string PoiId { get; set; } = string.Empty;
    public string TriggerType { get; set; } = string.Empty;
    public int? DurationListened { get; set; }
    public bool IsSuccess { get; set; } = true;
    public DateTime QueuedAtUtc { get; set; } = DateTime.UtcNow;
    public string Language { get; set; } = "vi-VN";
    public string Source { get; set; } = "mobile";
}
