using Microsoft.Data.Sqlite;
using SmartTour.Mobile.Models;

namespace SmartTour.Mobile.Data;

public sealed class PlaybackQueueRepository
{
    private bool _inited;

    private async Task InitAsync()
    {
        if (_inited) return;
        await using var conn = new SqliteConnection(Constants.ConnectionString);
        await conn.OpenAsync();
        var cmd = conn.CreateCommand();
        cmd.CommandText = @"
CREATE TABLE IF NOT EXISTS PlaybackQueue(
  Id INTEGER PRIMARY KEY AUTOINCREMENT,
  PoiId TEXT NOT NULL,
  TriggerType TEXT NOT NULL,
  DurationListened INTEGER NULL,
  IsSuccess INTEGER NOT NULL,
  Language TEXT NOT NULL,
  Source TEXT NOT NULL,
  QueuedAtUtc TEXT NOT NULL
);
";
        await cmd.ExecuteNonQueryAsync();
        _inited = true;
    }

    public async Task EnqueueAsync(PlaybackLogEnvelope item)
    {
        await InitAsync();
        await using var conn = new SqliteConnection(Constants.ConnectionString);
        await conn.OpenAsync();
        var cmd = conn.CreateCommand();
        cmd.CommandText = @"INSERT INTO PlaybackQueue(PoiId,TriggerType,DurationListened,IsSuccess,Language,Source,QueuedAtUtc)
VALUES($PoiId,$TriggerType,$Duration,$IsSuccess,$Language,$Source,$QueuedAtUtc);";
        cmd.Parameters.AddWithValue("$PoiId", item.PoiId);
        cmd.Parameters.AddWithValue("$TriggerType", item.TriggerType);
        cmd.Parameters.AddWithValue("$Duration", (object?)item.DurationListened ?? DBNull.Value);
        cmd.Parameters.AddWithValue("$IsSuccess", item.IsSuccess ? 1 : 0);
        cmd.Parameters.AddWithValue("$Language", item.Language);
        cmd.Parameters.AddWithValue("$Source", item.Source);
        cmd.Parameters.AddWithValue("$QueuedAtUtc", item.QueuedAtUtc.ToString("O"));
        await cmd.ExecuteNonQueryAsync();
    }

    public async Task<List<(long Id, PlaybackLogEnvelope Item)>> GetPendingAsync(int take = 50)
    {
        await InitAsync();
        var result = new List<(long, PlaybackLogEnvelope)>();
        await using var conn = new SqliteConnection(Constants.ConnectionString);
        await conn.OpenAsync();
        var cmd = conn.CreateCommand();
        cmd.CommandText = @"SELECT Id,PoiId,TriggerType,DurationListened,IsSuccess,Language,Source,QueuedAtUtc
FROM PlaybackQueue ORDER BY Id LIMIT $Take;";
        cmd.Parameters.AddWithValue("$Take", take);
        await using var r = await cmd.ExecuteReaderAsync();
        while (await r.ReadAsync())
        {
            result.Add((r.GetInt64(0), new PlaybackLogEnvelope
            {
                PoiId = r.GetString(1),
                TriggerType = r.GetString(2),
                DurationListened = r.IsDBNull(3) ? null : r.GetInt32(3),
                IsSuccess = r.GetInt32(4) == 1,
                Language = r.GetString(5),
                Source = r.GetString(6),
                QueuedAtUtc = DateTime.Parse(r.GetString(7))
            }));
        }
        return result;
    }

    public async Task DeleteAsync(IEnumerable<long> ids)
    {
        var arr = ids.Distinct().ToArray();
        if (arr.Length == 0) return;
        await InitAsync();
        await using var conn = new SqliteConnection(Constants.ConnectionString);
        await conn.OpenAsync();
        var cmd = conn.CreateCommand();
        var placeholders = arr.Select((_, i) => "$p" + i).ToArray();
        cmd.CommandText = $"DELETE FROM PlaybackQueue WHERE Id IN ({string.Join(',', placeholders)});";
        for (var i=0;i<arr.Length;i++) cmd.Parameters.AddWithValue(placeholders[i], arr[i]);
        await cmd.ExecuteNonQueryAsync();
    }

    public async Task<int> CountAsync()
    {
        await InitAsync();
        await using var conn = new SqliteConnection(Constants.ConnectionString);
        await conn.OpenAsync();
        var cmd = conn.CreateCommand();
        cmd.CommandText = "SELECT COUNT(*) FROM PlaybackQueue;";
        return Convert.ToInt32(await cmd.ExecuteScalarAsync());
    }
}
