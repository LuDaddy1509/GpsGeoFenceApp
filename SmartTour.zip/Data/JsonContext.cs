using SmartTour.Mobile.Models;
using System.Text.Json.Serialization;

namespace SmartTour.Mobile.Data;

[JsonSerializable(typeof(List<PoiDto>))]
[JsonSerializable(typeof(List<PlaybackLogEnvelope>))]
[JsonSerializable(typeof(PoiNarrationDto))]
public partial class JsonContext : JsonSerializerContext
{
}
