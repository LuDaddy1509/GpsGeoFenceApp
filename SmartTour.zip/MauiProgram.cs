using CommunityToolkit.Maui;
using Microsoft.Extensions.Logging;
using SmartTour.Mobile.Data;
using SmartTour.Mobile.Pages;
using SmartTour.Mobile.Platforms.Android.Services;
using SmartTour.Mobile.Services;
using SmartTour.Mobile.Services.Api;
using SmartTour.Mobile.Services.Audio;
using SmartTour.Mobile.Services.Narration;
using SmartTour.Mobile.Services.Sync;
using SmartTour.Mobile.ViewModels;
using ZXing.Net.Maui.Controls;

namespace SmartTour.Mobile;

public static class MauiProgram
{
    public static MauiApp CreateMauiApp()
    {
        var builder = MauiApp.CreateBuilder();
        builder
            .UseMauiApp<App>()
            .UseMauiMaps()
            .UseMauiCommunityToolkit()
            .UseBarcodeReader()
            .ConfigureFonts(fonts =>
            {
                fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular");
                fonts.AddFont("OpenSans-Semibold.ttf", "OpenSansSemibold");
            });

#if DEBUG
        builder.Logging.AddDebug();
#endif

#if ANDROID
        builder.Services.AddSingleton<ILocationService, AndroidLocationService>();
        builder.Services.AddSingleton<IGeofenceService, AndroidGeofenceService>();
        builder.Services.AddSingleton<IAudioPlayer, AndroidAudioPlayer>();
#else
        builder.Services.AddSingleton<ILocationService, NoopLocationService>();
        builder.Services.AddSingleton<IGeofenceService, NoopGeofenceService>();
        builder.Services.AddSingleton<IAudioPlayer, NoopAudioPlayer>();
#endif

        builder.Services.AddSingleton<AudioCache>();
        builder.Services.AddSingleton<NarrationManager>();
        builder.Services.AddSingleton<PoiDatabase>();
        builder.Services.AddSingleton<PlaybackQueueRepository>();
        builder.Services.AddSingleton<SyncMetadataRepository>();
        builder.Services.AddSingleton<MapViewModel>();
        builder.Services.AddSingleton<ExploreViewModel>();
        builder.Services.AddTransient<PoiDetailViewModel>();
        builder.Services.AddTransient<QrScanViewModel>();
        builder.Services.AddSingleton<AboutViewModel>();

        builder.Services.AddHttpClient<PoiApiClient>(http =>
        {
#if ANDROID
            http.BaseAddress = new Uri("http://10.0.2.2:5150");
#else
            http.BaseAddress = new Uri("http://localhost:5150");
#endif
            http.Timeout = TimeSpan.FromSeconds(30);
        });

        builder.Services.AddHttpClient<PlaybackApiClient>(http =>
        {
#if ANDROID
            http.BaseAddress = new Uri("http://10.0.2.2:5150");
#else
            http.BaseAddress = new Uri("http://localhost:5150");
#endif
            http.Timeout = TimeSpan.FromSeconds(30);
        });

        builder.Services.AddSingleton<PoiSyncService>();
        builder.Services.AddSingleton<OfflinePlaybackSyncService>();
        builder.Services.AddSingleton<MapPage>();
        builder.Services.AddTransient<ExplorePage>();
        builder.Services.AddTransient<PoiDetailPage>();
        builder.Services.AddTransient<QrScanPage>();
        builder.Services.AddSingleton<AboutPage>();

        var app = builder.Build();
        _ = Task.Run(async () =>
        {
            try
            {
                var db = app.Services.GetRequiredService<PoiDatabase>();
                await db.InitAsync();
                await Task.Delay(1500);
                var sync = app.Services.GetRequiredService<PoiSyncService>();
                await sync.SyncOnceAsync();
                sync.StartAutoSync(TimeSpan.FromMinutes(2));
                var offline = app.Services.GetRequiredService<OfflinePlaybackSyncService>();
                await offline.FlushAsync();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"[Startup] {ex}");
            }
        });

        return app;
    }
}
