using Microsoft.Maui.Networking;
using SmartTour.Mobile.Data;

namespace SmartTour.Mobile.Services.Sync;

public sealed class OfflinePlaybackSyncService
{
    private readonly PlaybackQueueRepository _queue;
    private readonly Api.PlaybackApiClient _playback;

    public OfflinePlaybackSyncService(PlaybackQueueRepository queue, Api.PlaybackApiClient playback)
    {
        _queue = queue;
        _playback = playback;
    }

    public async Task<int> FlushAsync(CancellationToken ct = default)
    {
        if (Connectivity.Current.NetworkAccess != NetworkAccess.Internet)
            return 0;

        var sentIds = new List<long>();
        var items = await _queue.GetPendingAsync(100);
        foreach (var (id, item) in items)
        {
            var ok = await _playback.TrySendAsync(item, ct);
            if (!ok) break;
            sentIds.Add(id);
        }

        await _queue.DeleteAsync(sentIds);
        return sentIds.Count;
    }
}
