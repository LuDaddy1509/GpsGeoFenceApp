using Microsoft.Maui.Networking;
using SmartTour.Mobile.Data;
using SmartTour.Mobile.Models;
using SmartTour.Mobile.Services.Api;

namespace SmartTour.Mobile.Services.Sync;

public sealed class PoiSyncService
{
    private readonly PoiApiClient _api;
    private readonly PoiDatabase _db;
    private readonly SyncMetadataRepository _meta;
    private CancellationTokenSource? _cts;
    private Task? _loop;

    public PoiSyncService(PoiApiClient api, PoiDatabase db, SyncMetadataRepository meta)
    {
        _api = api;
        _db = db;
        _meta = meta;
    }

    public void StartAutoSync(TimeSpan interval)
    {
        if (_loop is not null) return;
        _cts = new CancellationTokenSource();
        var ct = _cts.Token;
        _loop = Task.Run(async () =>
        {
            while (!ct.IsCancellationRequested)
            {
                try
                {
                    if (Connectivity.Current.NetworkAccess == NetworkAccess.Internet)
                        await SyncOnceAsync(ct);
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"[PoiSync] {ex.Message}");
                }
                await Task.Delay(interval, ct);
            }
        }, ct);
    }

    public async Task<DateTime?> SyncOnceAsync(CancellationToken ct = default)
    {
        if (Connectivity.Current.NetworkAccess != NetworkAccess.Internet)
            return null;

        var remote = await _api.GetAllAsync(LanguageService.Current, ct);
        foreach (var r in remote)
        {
            await _db.SaveAsync(new Poi
            {
                Id = r.Id, Name = r.Name, Description = r.Description ?? string.Empty,
                Latitude = r.Latitude, Longitude = r.Longitude, RadiusMeters = r.RadiusMeters,
                NearRadiusMeters = r.NearRadiusMeters, DebounceSeconds = r.DebounceSeconds, CooldownSeconds = r.CooldownSeconds,
                Priority = r.Priority, NarrationText = r.NarrationText, AudioUrl = r.AudioUrl, ImageUrl = r.ImageUrl, MapLink = r.MapLink,
                Language = r.Language ?? "vi-VN", IsActive = r.IsActive, UpdatedAt = r.UpdatedAt
            });
        }
        var now = DateTime.UtcNow;
        await _meta.SetLastSyncUtcAsync("pois", now);
        return now;
    }
}
