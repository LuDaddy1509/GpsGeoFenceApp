namespace SmartTour.Mobile.Services.Navigation;

public sealed record QrResolveResult(bool Success, string? PoiId = null, string? Error = null);

public static class QrResolver
{
    private const string DeepLinkPrefix = "smarttourism://poi/";

    public static QrResolveResult Parse(string? raw)
    {
        if (string.IsNullOrWhiteSpace(raw))
            return new(false, null, "QR trống hoặc không hợp lệ.");

        var value = raw.Trim();
        if (value.StartsWith(DeepLinkPrefix, StringComparison.OrdinalIgnoreCase))
            value = value[DeepLinkPrefix.Length..].Trim('/');

        if (string.IsNullOrWhiteSpace(value))
            return new(false, null, "Không đọc được mã POI từ QR.");

        return new(true, value);
    }
}
