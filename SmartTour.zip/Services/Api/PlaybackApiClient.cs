using System.Net.Http.Json;
using Microsoft.Maui.Storage;
using SmartTour.Mobile.Data;
using SmartTour.Mobile.Models;

namespace SmartTour.Mobile.Services.Api;

public sealed class PlaybackApiClient
{
    private readonly HttpClient _http;
    private readonly PlaybackQueueRepository _queue;

    public PlaybackApiClient(HttpClient http, PlaybackQueueRepository queue)
    {
        _http = http;
        _queue = queue;
    }

    public async Task LogAsync(string poiId, string triggerType, int? durationSeconds = null, bool success = true, CancellationToken ct = default)
    {
        var envelope = new PlaybackLogEnvelope
        {
            PoiId = poiId,
            TriggerType = triggerType,
            DurationListened = durationSeconds,
            IsSuccess = success,
            Language = LanguageService.Current,
            Source = triggerType.Equals("QR", StringComparison.OrdinalIgnoreCase) ? "qr-fallback" : "geofence"
        };

        if (!await TrySendAsync(envelope, ct))
        {
            await _queue.EnqueueAsync(envelope);
        }
    }

    public async Task<bool> TrySendAsync(PlaybackLogEnvelope item, CancellationToken ct = default)
    {
        try
        {
            var body = new
            {
                DeviceId = GetOrCreateDeviceId(),
                PoiId = item.PoiId,
                TriggerType = item.TriggerType,
                DurationListened = item.DurationListened,
                IsSuccess = item.IsSuccess,
                Language = item.Language,
                Source = item.Source
            };

            var resp = await _http.PostAsJsonAsync("/api/v1/playback", body, ct);
            return resp.IsSuccessStatusCode;
        }
        catch
        {
            return false;
        }
    }

    private static string GetOrCreateDeviceId()
    {
        const string key = "device_id";
        var id = Preferences.Get(key, string.Empty);
        if (string.IsNullOrWhiteSpace(id))
        {
            id = Guid.NewGuid().ToString("N");
            Preferences.Set(key, id);
        }
        return id;
    }
}
