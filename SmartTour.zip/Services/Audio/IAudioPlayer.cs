﻿using System;
using System.Collections.Generic;
using System.Text;
namespace SmartTour.Mobile.Services.Audio;
public interface IAudioPlayer
{
    Task PlayFileAsync(string filePath, CancellationToken ct = default);
    void Stop();
}
