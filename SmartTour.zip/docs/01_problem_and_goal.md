# SmartTour: Problem and Goal

## Problem
Đồ án du lịch thông minh thường bị chấm thấp khi chỉ dừng ở mức bản đồ hiển thị marker. Hội đồng cần thấy rõ bài toán thực tế: khách du lịch khó nắm ngữ cảnh từng điểm, tín hiệu mạng không ổn định, và việc trải nghiệm tại hiện trường phải hoạt động được cả khi không online liên tục.

## Goal
SmartTour giải quyết bài toán đó bằng một hệ thống C# gồm:
- **.NET MAUI mobile app** cho trải nghiệm tại hiện trường.
- **ASP.NET Core MapApi** cho nội dung, đồng bộ và thống kê.
- **Offline-first local SQLite** để app vẫn chạy khi mất mạng.
- **Geofence + QR fallback + audio narration** để vừa tự động vừa có phương án dự phòng.
- **Admin/dashboard** để chứng minh hệ thống có dữ liệu vận hành thật.
