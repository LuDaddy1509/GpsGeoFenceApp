# Setup và chạy demo SmartTour

## 1. Backend MapApi
- Mở `MapApi` trong Visual Studio.
- Kiểm tra `appsettings.json` và chỉnh lại `ConnectionStrings:Default` nếu SQL Server khác máy mẫu.
- Chạy migration hoặc import SQL nếu cần.
- Run project, xác nhận `http://localhost:5150/health` trả về OK.
- Mở `http://localhost:5150/admin/index.html`.
- Bấm `Nạp dữ liệu demo` để tạo bộ POI ban đầu.

## 2. Mobile app
- Chạy Android emulator.
- Mở `SmartTour.Mobile`.
- Trên Android emulator, app dùng `http://10.0.2.2:5150` để gọi backend local.
- Vào tab `Bản đồ`, chờ sync hoặc bấm Sync.
- Vào tab `Khám phá` để xem danh sách POI đã đồng bộ.
- Vào tab `QR` để kiểm tra fallback flow.

## 3. Demo hội đồng đề xuất
1. Giới thiệu tổng quan trong tab `Tổng quan`.
2. Chạy dashboard admin, cho thấy hệ thống có backend và quản trị nội dung.
3. Seed dữ liệu demo.
4. Sync app và hiển thị các POI trên bản đồ.
5. Mở `Khám phá` và `Chi tiết` để chứng minh UX mượt.
6. Quét QR để chứng minh fallback khi GPS yếu.
7. Mô phỏng offline rồi online lại để giải thích offline-first log sync.
