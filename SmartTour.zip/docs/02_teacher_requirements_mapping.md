# Mapping yêu cầu giảng viên

| Yêu cầu | SmartTour hiện có | Phần hấp thụ từ VN-GO |
|---|---|---|
| App C# rõ kiến trúc | MAUI app + MapApi | Chuẩn hóa ViewModel/Page/Service |
| Có dữ liệu và quản trị | API + admin dashboard | Tài liệu hóa scope và business rules |
| Có trải nghiệm người dùng | Map + bottom sheet + QR | ExplorePage + PoiDetailPage |
| Có logic nghiệp vụ rõ | Geofence gate, sync, language | Checklist test và mô tả rule |
| Có khả năng demo thuyết phục | Offline sync, QR fallback, audio | Demo script và teacher mapping |
