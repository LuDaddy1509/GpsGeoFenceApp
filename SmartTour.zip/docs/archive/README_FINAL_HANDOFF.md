# SmartTour - Final integrated handoff

## Những gì đã được nâng cấp trong gói này
- Tạo solution `SmartTour.sln` để mở cả mobile app và backend trong Visual Studio.
- Giữ `SmartTour.Mobile` làm trục chính, tiếp thu tư duy tổ chức repo từ VN-GO.
- Bổ sung `ExplorePage` có tìm kiếm, làm mới và thống kê POI.
- Bổ sung `PoiDetailPage`, `QrScanViewModel`, `QrResolver`, tab `Tổng quan` để app nhìn hoàn chỉnh hơn khi demo.
- Nâng cấp `MapApi` với admin dashboard, CRUD POI, seed dữ liệu demo, export JSON, system-info.
- Thêm dữ liệu mẫu trong `MapApi/Seed/sample-pois.json`.
- Thêm tài liệu setup, demo, business rules, checklist test.

## Cách mở trong Visual Studio
1. Mở file `SmartTour.sln`.
2. Chạy `MapApi` trước.
3. Mở `/admin/index.html` hoặc root `/` để vào dashboard admin.
4. Dùng nút **Nạp dữ liệu demo**.
5. Chạy `SmartTour.Mobile` trên Android emulator.
6. Tại app, vào `Bản đồ` và `Khám phá` để kiểm tra sync dữ liệu.

## Tài khoản admin mặc định
- Username: `admin`
- Password: `P@ssw0rd!`

## Những gì tôi chưa thể xác nhận trong môi trường này
- Chưa build/run thật vì môi trường hiện tại không có .NET SDK và Android workload.
- Chưa kiểm thử camera, GPS, geofence native và audio playback trên emulator/thiết bị thật.
- Chưa tạo audio/hình ảnh thật cho toàn bộ POI.

## Bạn nên bổ sung sau khi test local
- Ảnh thật của các điểm tham quan.
- Audio narration thật đa ngôn ngữ.
- Connection string SQL Server đúng máy của bạn.
- Chụp màn hình demo và số liệu thực tế để đưa vào báo cáo.
