# SmartTour refactor notes

## Mục tiêu
- Làm sạch repo, bỏ module project/task dư thừa.
- Chuẩn hóa lại ứng dụng thành SmartTour.
- Thể hiện luồng geofence -> QR fallback -> narration -> log -> sync -> dashboard.
- Bổ sung offline log queue và dashboard quản trị.

## Tính năng wow
- Auto Tour Mode: tự động phát thuyết minh khi vào vùng địa lý, gợi ý điểm kế tiếp và cho phép tắt/bật.

## Kịch bản demo
1. Đăng nhập `/admin` bằng Basic Auth để xem dashboard.
2. Thêm/sửa một POI và narration.
3. Mở app, bật Auto Tour Mode, đồng bộ dữ liệu.
4. Di chuyển vào geofence hoặc chạm pin để nghe thuyết minh.
5. Tắt mạng, quét QR để fallback, log vào queue offline.
6. Bật mạng, bấm Sync để flush log offline.
7. Quay lại dashboard xem số liệu tăng theo thời gian thực.
