# SmartTour Integrated Build

Bản này đã tích hợp các điểm mạnh phù hợp từ VN-GO-Travel vào SmartTour theo đúng stack C#.

## Những gì đã thêm
- `Application/Pages/ExplorePage.xaml`: danh sách khám phá.
- `Application/Pages/PoiDetailPage.xaml`: trang chi tiết điểm tham quan.
- `Application/ViewModels/ExploreViewModel.cs`
- `Application/ViewModels/PoiDetailViewModel.cs`
- `Application/ViewModels/QrScanViewModel.cs`
- `Application/Services/Navigation/QrResolver.cs`
- `docs/*`: bộ tài liệu nghiệp vụ, test checklist, QR strategy và demo script.

## Những gì đã chỉnh
- `AppShell`: thêm tab Explore và route `poidetail`.
- `MapPage`: hỗ trợ focus POI khi đi từ Explore sang Map.
- `QrScanPage`: chuyển phần parse/resolve QR sang ViewModel/service.
- `MauiProgram`: đăng ký các ViewModel/Page mới vào DI.

## Cách mở trong Visual Studio
1. Mở thư mục gốc của gói zip.
2. Mở `Application/SmartTour.Mobile.csproj` để chạy mobile app.
3. Mở `MapApi/MapApi.csproj` để chạy backend/admin.
4. Đặt `MapApi` chạy trước nếu bạn muốn test sync với local API.

## Lưu ý
- Gói này ưu tiên giảm rủi ro khi test nên chỉ tích hợp những phần "chuẩn bài C#" từ VN-GO, không copy nguyên repo còn lại.
