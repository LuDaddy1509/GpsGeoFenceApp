# SmartTour optimization package

## Những gì đã được tối ưu
- Dọn module dư thừa liên quan project/task/category/tag khỏi app mobile.
- Đổi tên ứng dụng từ `MauiApp1` thành `SmartTour Mobile`.
- Chuẩn hóa namespace chính sang `SmartTour.Mobile`.
- Tối ưu `MapPage` theo hướng trải nghiệm hoàn chỉnh: geofence -> hiển thị -> narration -> log -> sync.
- Bổ sung `MapViewModel` để tách trạng thái khỏi UI.
- Bổ sung offline playback queue (`PlaybackQueueRepository`) và `OfflinePlaybackSyncService`.
- Chuẩn hóa ngôn ngữ với `LanguageService`, đồng bộ lại dữ liệu theo ngôn ngữ đang chọn.
- Thêm chỉ báo Auto Tour Mode, trạng thái kết nối, trạng thái đồng bộ, và gợi ý POI tiếp theo.
- Thêm admin auth cơ bản cho khu vực `/admin` và `/api/v1/admin`.
- Thêm dashboard HTML đơn giản tại `/admin/index.html`.
- Thêm request validation cho admin create/update POI và playback log.
- Mở rộng `PlaybackLog` với `Language` và `Source` để chứng minh QR fallback và đa ngôn ngữ.

## Tính năng wow đã chọn
- **Auto Tour Mode**: người dùng bật chế độ tham quan tự động, app sẽ phát narration khi vào vùng geofence và gợi ý điểm tiếp theo theo ưu tiên/khoảng cách.

## Cách demo nhanh
1. Chạy API, mở `/admin/index.html`, đăng nhập Basic Auth bằng tài khoản trong `appsettings.json`.
2. Mở app, bấm `Sync`, chọn ngôn ngữ.
3. Đi vào geofence hoặc chạm pin để kích hoạt narration.
4. Tắt mạng, quét QR để fallback và tạo offline log.
5. Bật mạng, bấm `Sync` để flush log offline.
6. Quay lại dashboard để xem thống kê tăng lên.

## Các điểm cần nhóm hoàn thiện tiếp khi build thật
- Tạo migration EF cho hai cột mới `Language`, `Source` của `PoiPlaybackLog` nếu DB hiện tại chưa có.
- Đồng bộ lại namespace trong các file platform nếu IDE báo cache cũ.
- Cân nhắc tách tiếp `MapPage` thành `MapInteractionService` và `TourPlannerService` nếu muốn sạch hơn nữa.
- Thêm màn hình CRUD admin hoàn chỉnh nếu muốn nâng tiếp ngoài dashboard.
