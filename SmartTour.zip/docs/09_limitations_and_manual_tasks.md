# Những phần cần bạn bổ sung thủ công sau khi test

## Phần tôi đã làm được
- Tổ chức lại repo, solution, docs.
- Bổ sung UI/UX còn thiếu để app nhìn như sản phẩm hoàn chỉnh hơn.
- Bổ sung admin dashboard và CRUD cơ bản cho POI.
- Tạo seed dữ liệu mẫu để demo nhanh.

## Phần cần bạn bổ sung
- Build lỗi cụ thể nếu có trên máy Visual Studio của bạn.
- Quyền Android thực tế: camera, location always, background location.
- Audio file thật và ảnh thật cho từng điểm tham quan.
- Số liệu play log thật để dashboard đẹp hơn.
- QR code in ra giấy hoặc ảnh để test quét thật.
- Chỉnh SQL Server / LocalDB theo máy thật.

## Phần có thể cần vá tiếp
- Nếu MAUI XAML lỗi binding hoặc route, gửi output build để vá tiếp theo đúng lỗi.
- Nếu geofence native Android cần tinh chỉnh foreground service hoặc broadcast receiver, cần test trên emulator / thiết bị thật.
