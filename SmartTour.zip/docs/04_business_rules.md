# Core business rules

1. **Offline-first**: app đọc dữ liệu từ SQLite trước, network chỉ để sync và upload log.
2. **Single audio stream**: manual play được quyền ngắt luồng đang phát.
3. **QR fallback**: QR dùng để mở trực tiếp POI khi GPS không ổn định, không thay thế geofence.
4. **Geofence priority**: nếu nhiều điểm cùng gần, ưu tiên theo `Priority`, sau đó mới so khoảng cách.
5. **Language source of truth**: `LanguageService.Current` là nguồn trạng thái ngôn ngữ duy nhất.
6. **Sync evidence**: dashboard phải cho thấy số log chờ sync, số lần phát và số lần QR fallback.
