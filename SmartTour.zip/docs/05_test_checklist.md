# Test checklist

- [ ] Mở app lần đầu, MapPage hiển thị dữ liệu sau khi sync.
- [ ] Tắt mạng, chọn một điểm trên bản đồ vẫn xem được thông tin cục bộ.
- [ ] Quét QR với dạng `smarttourism://poi/<id>`.
- [ ] Quét QR với dạng `<id>` thuần.
- [ ] QR không hợp lệ hiển thị lỗi thân thiện.
- [ ] Mở ExplorePage và điều hướng sang PoiDetailPage.
- [ ] PoiDetailPage phát narration thủ công.
- [ ] Nút Stop dừng audio hiện tại.
- [ ] Nút Maps mở liên kết bản đồ ngoài.
- [ ] Bật mạng lại và flush offline playback logs thành công.
