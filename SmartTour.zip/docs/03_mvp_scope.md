# MVP scope

## P0
- MapPage với geofence, auto narration, sync.
- QrScanPage hoạt động với QR deep link hoặc mã POI.
- Dashboard admin hiển thị thống kê playback và trạng thái sync.

## P1
- ExplorePage liệt kê điểm tham quan.
- PoiDetailPage cho nghe thủ công, dừng audio, mở Google Maps.
- QrScanViewModel + QrResolver để giảm logic trong code-behind.

## P2
- Hoàn thiện legend cho dashboard.
- Tăng số test case nghiệm thu và script demo.
