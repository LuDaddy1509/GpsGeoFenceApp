# QR strategy

SmartTour hỗ trợ 2 dạng mã:

1. `smarttourism://poi/<id>`
2. `<id>` thuần

## Quy tắc xử lý
- Parse mã trong `QrResolver`.
- Resolve dữ liệu cục bộ qua `PoiDatabase.GetByIdAsync`.
- Nếu tìm thấy POI thì phát narration thủ công và ghi log nguồn `QR`.
- Nếu không tìm thấy thì hiển thị lỗi rõ ràng, cho phép quét lại.

## Lý do chọn cách này
- Dễ demo trên thiết bị thật.
- Không phụ thuộc hoàn toàn vào internet.
- Logic parse rõ ràng, đúng tinh thần tách UI khỏi nghiệp vụ trong đồ án C#.
