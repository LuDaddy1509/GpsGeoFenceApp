# Demo script

1. Mở dashboard admin: giới thiệu số POI, playback, QR fallback và sync pending.
2. Mở **ExplorePage**: cho thấy app không chỉ có bản đồ mà còn có danh sách khám phá.
3. Chọn một điểm để vào **PoiDetailPage**: bấm **Nghe** và **Dừng**.
4. Quay lại **MapPage**: bật Auto Tour và mô tả geofence ưu tiên theo Priority.
5. Tắt mạng, quét QR để mở đúng POI từ dữ liệu cục bộ.
6. Bật mạng, bấm Sync để chứng minh offline-first và upload log hoạt động.
