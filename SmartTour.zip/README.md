# SmartTour

Đây là bản SmartTour đã được dọn lại theo cấu trúc gọn để dễ mở bằng Visual Studio, dễ xem, dễ nâng cấp và dễ chỉnh sửa.

## Cấu trúc chính
- `Views/`: các màn hình MAUI
- `ViewModels/`: logic giao diện
- `Models/`: model dữ liệu
- `Services/`: service nghiệp vụ
- `Resources/`: font, icon, seed data, styles
- `Platforms/`: mã riêng theo nền tảng
- `MapApi/`: backend ASP.NET Core
- `AdminWeb/`: giao diện quản lý tĩnh
- `docs/`: tài liệu đồ án

## Mở bằng Visual Studio
1. Mở `SmartTour.sln`
2. Chạy `MapApi`
3. Chạy `SmartTour.Mobile` trên Android emulator

## Ghi chú
- Các ghi chú kỹ thuật rời đã được chuyển vào `docs/` để thư mục gốc gọn hơn.
- Thư mục `Views/` tương đương thư mục `Pages/` trước đây, chỉ đổi để cấu trúc dễ nhìn hơn.
