using SmartTour.Mobile.Data;
using SmartTour.Mobile.Models;
using SmartTour.Mobile.Services;
using SmartTour.Mobile.Services.Api;
using SmartTour.Mobile.Services.Narration;
using SmartTour.Mobile.Services.Sync;
using SmartTour.Mobile.ViewModels;
using Microsoft.Maui.ApplicationModel;
using Microsoft.Maui.Controls.Maps;
using Microsoft.Maui.Devices;
using Microsoft.Maui.Devices.Sensors;
using Microsoft.Maui.Graphics;
using Microsoft.Maui.Maps;

namespace SmartTour.Mobile.Pages;

[QueryProperty(nameof(PoiId), "poiId")]
public partial class MapPage : ContentPage
{
    private readonly IGeofenceService _geofence;
    private readonly ILocationService _location;
    private readonly PoiDatabase _db;
    private readonly NarrationManager _narration;
    private readonly PoiSyncService _poiSync;
    private readonly PlaybackApiClient _playback;
    private readonly OfflinePlaybackSyncService _offlinePlaybackSync;
    private readonly PlaybackQueueRepository _playbackQueue;
    private readonly MapViewModel _vm;

    private string? _poiId;
    public string? PoiId
    {
        get => _poiId;
        set => _poiId = value;
    }

    private string _currentLang = LanguageService.Current;
    private readonly List<Poi> _pois = new();
    private readonly Dictionary<string, Pin> _pinMap = new();
    private CancellationTokenSource? _cts;
    private Poi? _nearestPoi;
    private Location? _userLocation;
    private static readonly Location _hcmCenter = new(10.776889, 106.700806);

    double _sheetCollapsedOffset = -1;
    readonly double _sheetExpandedOffset = 0;
    double _sheetStartPanY = 0;
    bool _sheetReady = false;
    const double SheetPeekHeight = 160;

    public MapPage(IGeofenceService geofence, ILocationService location, PoiDatabase db, NarrationManager narration, PoiSyncService poiSync, PlaybackApiClient playback, OfflinePlaybackSyncService offlinePlaybackSync, PlaybackQueueRepository playbackQueue, MapViewModel vm)
    {
        InitializeComponent();
        _geofence = geofence; _location = location; _db = db; _narration = narration; _poiSync = poiSync; _playback = playback; _offlinePlaybackSync = offlinePlaybackSync; _playbackQueue = playbackQueue; _vm = vm;
        BindingContext = _vm;

        ToolbarItems.Add(new ToolbarItem { Text = "Explore", Command = new Command(async () => await Shell.Current.GoToAsync("//explore")) });
        ToolbarItems.Add(new ToolbarItem { Text = "Reset", Command = new Command(() => MyMap.MoveToRegion(MapSpan.FromCenterAndRadius(_hcmCenter, Distance.FromKilometers(3)))) });
        ToolbarItems.Add(new ToolbarItem { Text = "QR", Command = new Command(async () => await Shell.Current.GoToAsync("qrscan")) });
        ToolbarItems.Add(new ToolbarItem { Text = "Sync", Order = ToolbarItemOrder.Secondary, Command = new Command(async () => await SyncAndRefreshAsync()) });

        BtnOpenInMaps.Clicked += async (_, _) => await OpenMapsAsync(_nearestPoi);
        BottomSheet.SizeChanged += (_, _) => SetupBottomSheetOffsets();
        SizeChanged += (_, _) => SetupBottomSheetOffsets();

        _geofence.OnPoiEvent += async (poi, type) =>
        {
            if (!_vm.AutoTourEnabled && !string.Equals(type, "TAP", StringComparison.OrdinalIgnoreCase))
                return;

            if (type == "EXIT")
            {
                await MainThread.InvokeOnMainThreadAsync(ClearHighlight);
                return;
            }

            var evType = type == "ENTER" ? PoiEventType.Enter : PoiEventType.Near;
            await PresentPoiAsync(poi, type, evType);
        };
    }

    private async Task SyncAndRefreshAsync()
    {
        var serverTime = await _poiSync.SyncOnceAsync();
        var flushed = await _offlinePlaybackSync.FlushAsync();
        await ReloadPoisAsync();
        if (_pois.Count > 0) await _geofence.RegisterAsync(_pois);
        var pending = await _playbackQueue.CountAsync();
        _vm.UpdateSync(serverTime ?? DateTime.UtcNow, pending);
        _vm.StatusText = $"Đã đồng bộ {_pois.Count} điểm. Flush offline logs: {flushed}.";
        _vm.ConnectivityText = pending > 0 ? "Offline-first • còn log chờ sync" : "Online • dữ liệu mới nhất";
    }

    private async Task PresentPoiAsync(Poi poi, string triggerSource, PoiEventType eventType)
    {
        await MainThread.InvokeOnMainThreadAsync(() =>
        {
            _vm.TriggerSourceText = $"Nguồn kích hoạt: {triggerSource}";
            HighlightPoi(poi, triggerSource);
            ShowDetail(poi);
        });
        var started = DateTime.UtcNow;
        await _narration.HandleAsync(new Announcement(poi, eventType, started, _currentLang));
        var dur = (int)(DateTime.UtcNow - started).TotalSeconds;
        await _playback.LogAsync(poi.Id, triggerSource, dur > 0 ? dur : null);
    }

    private void RefreshLangBar()
    {
        var map = new Dictionary<string, Border> { ["vi-VN"] = BtnVi, ["en-US"] = BtnEn, ["ja-JP"] = BtnJa, ["ko-KR"] = BtnKo };
        foreach (var (code, btn) in map)
            btn.Background = new SolidColorBrush(code == _currentLang ? Color.FromArgb("#1976D2") : Color.FromArgb("#333333"));
    }

    private async void OnLangTapped(object? sender, TappedEventArgs e)
    {
        var code = e.Parameter as string;
        if (string.IsNullOrWhiteSpace(code)) return;
        _currentLang = code;
        LanguageService.Set(code);
        RefreshLangBar();
        _vm.StatusText = $"Đã chuyển ngôn ngữ sang {LanguageService.Display(code)}";
        await SyncAndRefreshAsync();
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        RefreshLangBar();
        MyMap.MoveToRegion(MapSpan.FromCenterAndRadius(_hcmCenter, Distance.FromKilometers(3)));
        if (!await EnsureLocationPermissionsAsync()) return;
        await MainThread.InvokeOnMainThreadAsync(() => MyMap.IsShowingUser = true);
        await SyncAndRefreshAsync();
        await FocusFromNavigationAsync();
        _ = Task.Run(MoveToRealLocationAsync);
        StartTracking();
    }

    protected override void OnDisappearing() { StopTracking(); base.OnDisappearing(); }

    private async Task FocusFromNavigationAsync()
    {
        if (string.IsNullOrWhiteSpace(PoiId))
            return;

        var poi = await _db.GetByIdAsync(PoiId);
        if (poi == null)
            return;

        await MainThread.InvokeOnMainThreadAsync(() =>
        {
            HighlightPoi(poi, "EXPLORE");
            ShowDetail(poi);
        });
        PoiId = null;
    }

    private async Task<bool> EnsureLocationPermissionsAsync()
    {
        var when = await Permissions.RequestAsync<Permissions.LocationWhenInUse>();
        if (when != PermissionStatus.Granted) return false;
        if (DeviceInfo.Platform != DevicePlatform.Android || !OperatingSystem.IsAndroidVersionAtLeast(30))
            _ = await Permissions.RequestAsync<Permissions.LocationAlways>();
        return true;
    }

    private async Task ReloadPoisAsync()
    {
        var pois = await _db.GetActivePoisAsync();
        await MainThread.InvokeOnMainThreadAsync(() =>
        {
            _pois.Clear(); _pinMap.Clear(); MyMap.Pins.Clear();
            foreach (var p in pois)
            {
                _pois.Add(p);
                var pin = new Pin { Label = p.Name, Address = p.Description, Location = new Location(p.Latitude, p.Longitude), Type = PinType.Place };
                pin.MarkerClicked += async (_, e) => { e.HideInfoWindow = false; await PresentPoiAsync(p, "TAP", PoiEventType.Tap); };
                _pinMap[p.Id] = pin;
                MyMap.Pins.Add(pin);
            }
        });
    }

    private async Task MoveToRealLocationAsync()
    {
        try
        {
            var loc = await Geolocation.GetLocationAsync(new GeolocationRequest(GeolocationAccuracy.Best, TimeSpan.FromSeconds(10)));
            if (loc == null) return;
            _userLocation = loc;
            await MainThread.InvokeOnMainThreadAsync(() => MyMap.MoveToRegion(MapSpan.FromCenterAndRadius(loc, Distance.FromKilometers(1))));
        }
        catch (Exception ex) { System.Diagnostics.Debug.WriteLine($"[GPS] {ex.Message}"); }
    }

    private void StartTracking()
    {
        _cts?.Cancel(); _cts = new CancellationTokenSource();
        _ = TrackLoopAsync(_cts.Token);
        _location.StartTracking((lat, lng) => _userLocation = new Location(lat, lng));
    }

    private void StopTracking() { _cts?.Cancel(); _cts = null; _location.StopTracking(); }

    private async Task TrackLoopAsync(CancellationToken token)
    {
        var req = new GeolocationRequest(GeolocationAccuracy.Medium, TimeSpan.FromSeconds(10));
        while (!token.IsCancellationRequested)
        {
            try
            {
                var loc = await Geolocation.GetLocationAsync(req, token);
                if (loc == null) { await Task.Delay(5000, token); continue; }
                _userLocation = loc;
                Poi? nearest = null; double nearestDist = double.MaxValue;
                foreach (var poi in _pois.ToList())
                {
                    var dist = Location.CalculateDistance(new Location(poi.Latitude, poi.Longitude), loc, DistanceUnits.Kilometers) * 1000.0;
                    if (dist > poi.NearRadiusMeters) continue;
                    var thisPri = poi.Priority ?? 999; var bestPri = nearest?.Priority ?? 999;
                    if (nearest == null || thisPri < bestPri || (thisPri == bestPri && dist < nearestDist)) { nearest = poi; nearestDist = dist; }
                }
                if (nearest != null && GeofenceEventGate.ShouldAccept(nearest.Id, "NEAR", nearest.DebounceSeconds, nearest.CooldownSeconds))
                {
                    await PresentPoiAsync(nearest, "NEAR", PoiEventType.Near);
                    _vm.NextPoiHint = BuildNextPoiHint(nearest);
                }
                else if (nearest == null) await MainThread.InvokeOnMainThreadAsync(ClearHighlight);
            }
            catch (Exception ex) when (!token.IsCancellationRequested) { System.Diagnostics.Debug.WriteLine($"[Loop] {ex.Message}"); }
            await Task.Delay(5000, token);
        }
    }

    private string BuildNextPoiHint(Poi current)
    {
        if (_userLocation == null) return "Chưa xác định được điểm tiếp theo.";
        var next = _pois.Where(x => x.Id != current.Id)
            .OrderBy(x => x.Priority ?? 999)
            .ThenBy(x => Location.CalculateDistance(_userLocation, new Location(x.Latitude, x.Longitude), DistanceUnits.Kilometers))
            .FirstOrDefault();
        return next == null ? "Bạn đã ở điểm cuối trong lộ trình gợi ý." : $"Gợi ý tiếp theo: {next.Name}";
    }

    private void HighlightPoi(Poi poi, string status)
    {
        ClearHighlight();
        _nearestPoi = poi;
        if (_pinMap.TryGetValue(poi.Id, out var pin)) pin.Label = $"★ {poi.Name}";
        _vm.StatusText = $"{poi.Name} • {status} • {LanguageService.Display(_currentLang)}";
    }

    private void ClearHighlight()
    {
        if (_nearestPoi == null) return;
        if (_pinMap.TryGetValue(_nearestPoi.Id, out var pin)) pin.Label = _nearestPoi.Name;
        _nearestPoi = null;
    }

    private void ShowDetail(Poi? poi)
    {
        if (poi == null) return;
        DetailName.Text = poi.Name;
        DetailDesc.Text = string.IsNullOrWhiteSpace(poi.Description) ? "(Không có mô tả)" : poi.Description;
        DetailCoord.Text = $"📍 {poi.Latitude:F6}, {poi.Longitude:F6}";
        DetailRadius.Text = $"🔵 Geofence: {poi.RadiusMeters}m | Near: {poi.NearRadiusMeters}m | Priority: {poi.Priority ?? 999}";
        DetailNextHint.Text = BuildNextPoiHint(poi);
        DetailImage.Source = !string.IsNullOrWhiteSpace(poi.ImageUrl) ? poi.ImageUrl : null;
        LblPoiLink.Text = !string.IsNullOrWhiteSpace(poi.MapLink) ? poi.MapLink : $"https://maps.google.com/?q={poi.Latitude},{poi.Longitude}";
        _ = ExpandSheetAsync();
        MyMap.MoveToRegion(MapSpan.FromCenterAndRadius(new Location(poi.Latitude, poi.Longitude), Distance.FromMeters(400)));
    }

    private async Task OpenMapsAsync(Poi? poi)
    {
        if (poi == null) return;
        var url = !string.IsNullOrWhiteSpace(poi.MapLink) ? poi.MapLink : $"https://maps.google.com/?q={poi.Latitude},{poi.Longitude}";
        try { await Launcher.OpenAsync(new Uri(url)); } catch (Exception ex) { System.Diagnostics.Debug.WriteLine($"[Maps] {ex.Message}"); }
    }

    void SetupBottomSheetOffsets() { if (BottomSheet.Height <= 0 || Height <= 0) return; _sheetCollapsedOffset = Math.Max(0, BottomSheet.Height - SheetPeekHeight); if (!_sheetReady) { BottomSheet.TranslationY = _sheetCollapsedOffset; _sheetReady = true; } }
    Task ExpandSheetAsync() => BottomSheet.TranslateToAsync(0, _sheetExpandedOffset, 180, Easing.CubicOut);
    void BottomSheet_TapHeader(object? sender, EventArgs e) { if (!_sheetReady) return; var isCollapsed = Math.Abs(BottomSheet.TranslationY - _sheetCollapsedOffset) < 1; _ = BottomSheet.TranslateToAsync(0, isCollapsed ? _sheetExpandedOffset : _sheetCollapsedOffset, 200, Easing.CubicOut); }
    void BottomSheet_PanUpdated(object? sender, PanUpdatedEventArgs e)
    {
        if (!_sheetReady) return;
        switch (e.StatusType)
        {
            case GestureStatus.Started: _sheetStartPanY = BottomSheet.TranslationY; break;
            case GestureStatus.Running: BottomSheet.TranslationY = Math.Clamp(_sheetStartPanY + e.TotalY, _sheetExpandedOffset, _sheetCollapsedOffset); break;
            case GestureStatus.Completed:
            case GestureStatus.Canceled:
                _ = BottomSheet.TranslateToAsync(0, BottomSheet.TranslationY > _sheetCollapsedOffset / 2 ? _sheetCollapsedOffset : _sheetExpandedOffset, 180, Easing.CubicOut);
                break;
        }
    }
}
