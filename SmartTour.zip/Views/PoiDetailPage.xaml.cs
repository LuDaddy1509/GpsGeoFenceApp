using SmartTour.Mobile.ViewModels;

namespace SmartTour.Mobile.Pages;

[QueryProperty(nameof(PoiId), "poiId")]
public partial class PoiDetailPage : ContentPage
{
    private readonly PoiDetailViewModel _vm;
    private string? _poiId;

    public string? PoiId
    {
        get => _poiId;
        set
        {
            _poiId = value;
            if (!string.IsNullOrWhiteSpace(_poiId))
                _ = _vm.LoadAsync(_poiId);
        }
    }

    public PoiDetailPage(PoiDetailViewModel vm)
    {
        InitializeComponent();
        _vm = vm;
        BindingContext = _vm;
    }
}
