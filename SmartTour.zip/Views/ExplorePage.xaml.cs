using SmartTour.Mobile.ViewModels;

namespace SmartTour.Mobile.Pages;

public partial class ExplorePage : ContentPage
{
    private readonly ExploreViewModel _vm;

    public ExplorePage(ExploreViewModel vm)
    {
        InitializeComponent();
        _vm = vm;
        BindingContext = _vm;
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        await _vm.LoadAsync();
    }

    private async void OnDetailClicked(object? sender, EventArgs e)
    {
        if (sender is Button button && button.CommandParameter is string poiId && !string.IsNullOrWhiteSpace(poiId))
            await Shell.Current.GoToAsync($"poidetail?poiId={Uri.EscapeDataString(poiId)}");
    }

    private async void OnMapClicked(object? sender, EventArgs e)
    {
        if (sender is Button button && button.CommandParameter is string poiId && !string.IsNullOrWhiteSpace(poiId))
            await Shell.Current.GoToAsync($"//map?poiId={Uri.EscapeDataString(poiId)}");
    }
}
