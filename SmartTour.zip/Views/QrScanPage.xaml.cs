﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Maui.ApplicationModel;
using Microsoft.Maui.Controls;
using Microsoft.Maui.Dispatching;
using SmartTour.Mobile.Services.Api;
using SmartTour.Mobile.Services.Narration;
using SmartTour.Mobile.ViewModels;
using ZXing.Net.Maui;

namespace SmartTour.Mobile.Pages;

public partial class QrScanPage : ContentPage
{
    private readonly NarrationManager _narration;
    private readonly PlaybackApiClient _playback;
    private readonly QrScanViewModel _vm;
    private bool _isProcessing;

    public QrScanPage(QrScanViewModel vm, NarrationManager narration, PlaybackApiClient playback)
    {
        InitializeComponent();
        _vm = vm;
        _narration = narration;
        _playback = playback;
        BindingContext = _vm;

        BarcodeReader.Options = new BarcodeReaderOptions
        {
            Formats = BarcodeFormats.TwoDimensional,
            AutoRotate = true,
            Multiple = false
        };
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();

        var status = await Permissions.RequestAsync<Permissions.Camera>();
        if (status != PermissionStatus.Granted)
        {
            await DisplayAlertAsync("Cần quyền Camera", "Vui lòng cấp quyền camera để quét mã QR.", "OK");
            await CloseAsync();
            return;
        }

        _isProcessing = false;
        BarcodeReader.IsDetecting = true;
        _vm.StatusText = "Sẵn sàng quét";
    }

    protected override void OnDisappearing()
    {
        BarcodeReader.IsDetecting = false;
        base.OnDisappearing();
    }

    private void OnBarcodesDetected(object? sender, BarcodeDetectionEventArgs e)
    {
        if (_isProcessing) return;

        var raw = e.Results?.FirstOrDefault()?.Value;
        if (string.IsNullOrWhiteSpace(raw)) return;

        _isProcessing = true;
        MainThread.BeginInvokeOnMainThread(async () => await HandleQrValueAsync(raw.Trim()));
    }

    private async Task HandleQrValueAsync(string raw)
    {
        try
        {
            BarcodeReader.IsDetecting = false;
            var (poi, error) = await _vm.ResolvePoiAsync(raw);
            if (poi == null)
            {
                await DisplayAlertAsync("Không tìm thấy", error ?? "Mã QR không hợp lệ hoặc POI chưa được tải.", "OK");
                AllowRescan();
                return;
            }

            var started = DateTime.UtcNow;
            await _narration.HandleAsync(new Announcement(poi, PoiEventType.Tap, started, LanguageService.Current));
            var dur = (int)(DateTime.UtcNow - started).TotalSeconds;
            _ = _playback.LogAsync(poi.Id, "QR", dur > 0 ? dur : null);

            await DisplayAlertAsync(poi.Name,
                string.IsNullOrWhiteSpace(poi.Description) ? "Đang phát thuyết minh..." : poi.Description,
                "OK");

            await Shell.Current.GoToAsync($"poidetail?poiId={Uri.EscapeDataString(poi.Id)}");
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[QR] {ex}");
            _vm.StatusText = "Lỗi xử lý mã QR";
            AllowRescan();
        }
    }

    private void AllowRescan()
    {
        _isProcessing = false;
        BarcodeReader.IsDetecting = true;
        _vm.StatusText = "Sẵn sàng quét";
    }

    private async void OnCloseClicked(object? sender, EventArgs e)
    {
        await CloseAsync();
    }

    private Task CloseAsync() => Shell.Current.GoToAsync("..");
}
