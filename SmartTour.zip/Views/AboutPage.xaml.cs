using SmartTour.Mobile.ViewModels;

namespace SmartTour.Mobile.Pages;

public partial class AboutPage : ContentPage
{
    private readonly AboutViewModel _vm;

    public AboutPage(AboutViewModel vm)
    {
        InitializeComponent();
        _vm = vm;
        BindingContext = _vm;
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        await _vm.LoadAsync();
    }
}
