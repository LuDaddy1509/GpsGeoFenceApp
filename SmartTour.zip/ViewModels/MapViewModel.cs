using CommunityToolkit.Mvvm.ComponentModel;

namespace SmartTour.Mobile.ViewModels;

public partial class MapViewModel : ObservableObject
{
    [ObservableProperty] private string statusText = "Đang sẵn sàng đồng bộ dữ liệu.";
    [ObservableProperty] private string connectivityText = "Offline-first";
    [ObservableProperty] private string syncText = "Chưa đồng bộ";
    [ObservableProperty] private bool autoTourEnabled = true;
    [ObservableProperty] private string triggerSourceText = "GPS";
    [ObservableProperty] private string nextPoiHint = "Di chuyển đến điểm gần nhất để nghe thuyết minh tự động.";

    public void UpdateSync(DateTime serverTimeUtc, int pendingOfflineLogs)
    {
        SyncText = $"Đồng bộ lúc {serverTimeUtc.ToLocalTime():HH:mm:ss} • offline logs: {pendingOfflineLogs}";
    }
}
