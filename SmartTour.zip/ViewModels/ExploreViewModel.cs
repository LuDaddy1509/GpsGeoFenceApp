using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using SmartTour.Mobile.Data;
using SmartTour.Mobile.Models;
using System.Collections.ObjectModel;

namespace SmartTour.Mobile.ViewModels;

public partial class ExploreViewModel : ObservableObject
{
    private readonly PoiDatabase _db;
    private readonly List<Poi> _allPois = new();

    public ObservableCollection<Poi> Pois { get; } = new();

    [ObservableProperty] private bool isBusy;
    [ObservableProperty] private string emptyStateText = "Đang tải dữ liệu điểm tham quan...";
    [ObservableProperty] private string summaryText = "Khám phá các điểm nổi bật, chọn điểm để xem chi tiết hoặc mở trên bản đồ.";
    [ObservableProperty] private string searchText = string.Empty;
    [ObservableProperty] private string statsText = "0 POI";

    public ExploreViewModel(PoiDatabase db)
    {
        _db = db;
    }

    partial void OnSearchTextChanged(string value) => ApplyFilter();

    [RelayCommand]
    public async Task LoadAsync()
    {
        if (IsBusy) return;
        try
        {
            IsBusy = true;
            await _db.InitAsync();
            var pois = await _db.GetActivePoisAsync();
            _allPois.Clear();
            _allPois.AddRange(pois.OrderBy(x => x.Priority ?? 999).ThenBy(x => x.Name));
            ApplyFilter();

            EmptyStateText = _allPois.Count == 0
                ? "Chưa có điểm tham quan nào được đồng bộ. Hãy mở Map hoặc bấm Sync trước."
                : $"Tìm thấy {_allPois.Count} điểm tham quan sẵn sàng cho chế độ offline-first.";
            SummaryText = _allPois.Count == 0
                ? "Danh sách sẽ tự đầy sau khi đồng bộ dữ liệu từ MapApi."
                : "Bạn có thể tìm kiếm theo tên, mở trang chi tiết để nghe thuyết minh thủ công, xem geofence và mở Google Maps.";
            UpdateStats();
        }
        finally
        {
            IsBusy = false;
        }
    }

    [RelayCommand]
    public Task RefreshAsync() => LoadAsync();

    private void ApplyFilter()
    {
        IEnumerable<Poi> items = _allPois;
        if (!string.IsNullOrWhiteSpace(SearchText))
        {
            var keyword = SearchText.Trim();
            items = items.Where(x =>
                x.Name.Contains(keyword, StringComparison.OrdinalIgnoreCase) ||
                x.Description.Contains(keyword, StringComparison.OrdinalIgnoreCase));
        }

        Pois.Clear();
        foreach (var poi in items)
            Pois.Add(poi);

        UpdateStats();
    }

    private void UpdateStats()
    {
        var priorityCount = Pois.Count(x => (x.Priority ?? 999) <= 3);
        StatsText = $"{Pois.Count} POI hiển thị • {priorityCount} điểm ưu tiên cao • Offline-first";
    }
}
