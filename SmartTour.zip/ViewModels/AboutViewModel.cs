using CommunityToolkit.Mvvm.ComponentModel;
using SmartTour.Mobile.Data;

namespace SmartTour.Mobile.ViewModels;

public partial class AboutViewModel : ObservableObject
{
    [ObservableProperty] private string projectName = "SmartTour - Đồ án du lịch thông minh";
    [ObservableProperty] private string summaryText = "Ứng dụng MAUI C# cho trải nghiệm tham quan thông minh: geofence tự phát, QR fallback, offline-first, đồng bộ MapApi và dashboard quản trị.";
    [ObservableProperty] private string architectureText = "Mobile: .NET MAUI + MVVM + SQLite cục bộ. Backend: ASP.NET Core + EF Core + SQL Server. Dữ liệu: POI, narration, playback log, thống kê dashboard.";
    [ObservableProperty] private string featureText = "Geofence • QR fallback • Audio narration • Offline log sync • Dashboard quản trị • Đa ngôn ngữ • Explore/Detail flow";
    [ObservableProperty] private string readinessText = "Đang kiểm tra dữ liệu cục bộ...";
    [ObservableProperty] private string demoText = "Demo đề xuất: Sync dữ liệu → Explore → mở chi tiết → quét QR → xem dashboard admin → mô phỏng offline log.";

    private readonly PoiDatabase _db;

    public AboutViewModel(PoiDatabase db)
    {
        _db = db;
    }

    public async Task LoadAsync()
    {
        await _db.InitAsync();
        var count = (await _db.GetActivePoisAsync()).Count;
        ReadinessText = count == 0
            ? "Chưa có POI cục bộ. Hãy chạy MapApi và bấm Sync để nạp dữ liệu demo."
            : $"Đã có {count} POI cục bộ sẵn sàng cho demo offline-first.";
    }
}
