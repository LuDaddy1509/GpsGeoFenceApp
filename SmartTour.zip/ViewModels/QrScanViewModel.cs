using CommunityToolkit.Mvvm.ComponentModel;
using SmartTour.Mobile.Data;
using SmartTour.Mobile.Models;
using SmartTour.Mobile.Services.Navigation;

namespace SmartTour.Mobile.ViewModels;

public partial class QrScanViewModel : ObservableObject
{
    private readonly PoiDatabase _db;

    [ObservableProperty] private bool isBusy;
    [ObservableProperty] private string statusText = "Sẵn sàng quét";

    public QrScanViewModel(PoiDatabase db)
    {
        _db = db;
    }

    public async Task<(Poi? poi, string? error)> ResolvePoiAsync(string raw)
    {
        if (IsBusy)
            return (null, "Đang xử lý mã QR trước đó.");

        IsBusy = true;
        try
        {
            StatusText = "Đang xử lý...";
            var parsed = QrResolver.Parse(raw);
            if (!parsed.Success || string.IsNullOrWhiteSpace(parsed.PoiId))
            {
                StatusText = parsed.Error ?? "Mã QR không hợp lệ.";
                return (null, StatusText);
            }

            await _db.InitAsync();
            var poi = await _db.GetByIdAsync(parsed.PoiId);
            if (poi == null)
            {
                StatusText = $"Không tìm thấy POI cục bộ cho mã {parsed.PoiId}.";
                return (null, StatusText);
            }

            StatusText = $"✓ {poi.Name}";
            return (poi, null);
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[QrScan/ResolvePoiAsync] {ex}");
            StatusText = "Lỗi xử lý mã QR.";
            return (null, StatusText);
        }
        finally
        {
            IsBusy = false;
        }
    }
}
