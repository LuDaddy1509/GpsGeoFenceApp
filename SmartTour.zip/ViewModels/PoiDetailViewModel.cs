using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using SmartTour.Mobile.Data;
using SmartTour.Mobile.Models;
using SmartTour.Mobile.Services.Narration;
using Microsoft.Maui.ApplicationModel;

namespace SmartTour.Mobile.ViewModels;

public partial class PoiDetailViewModel : ObservableObject
{
    private readonly PoiDatabase _db;
    private readonly NarrationManager _narration;

    [ObservableProperty] private Poi? poi;
    [ObservableProperty] private bool isBusy;
    [ObservableProperty] private string statusText = "Sẵn sàng phát thuyết minh thủ công.";
    [ObservableProperty] private string coordinatesText = string.Empty;
    [ObservableProperty] private string radiusText = string.Empty;
    [ObservableProperty] private string mapLinkText = string.Empty;
    [ObservableProperty] private string narrationHint = "Manual audio có thể ngắt luồng đang phát để ưu tiên điểm người dùng chọn.";

    public PoiDetailViewModel(PoiDatabase db, NarrationManager narration)
    {
        _db = db;
        _narration = narration;
    }

    public async Task LoadAsync(string poiId)
    {
        if (string.IsNullOrWhiteSpace(poiId))
        {
            StatusText = "Thiếu mã POI để mở chi tiết.";
            return;
        }

        IsBusy = true;
        try
        {
            await _db.InitAsync();
            Poi = await _db.GetByIdAsync(poiId);
            if (Poi == null)
            {
                StatusText = "Không tìm thấy điểm tham quan này trong bộ nhớ cục bộ.";
                CoordinatesText = string.Empty;
                RadiusText = string.Empty;
                MapLinkText = string.Empty;
                return;
            }

            CoordinatesText = $"📍 {Poi.Latitude:F6}, {Poi.Longitude:F6}";
            RadiusText = $"Geofence {Poi.RadiusMeters}m • Near {Poi.NearRadiusMeters}m • Priority {Poi.Priority ?? 999}";
            MapLinkText = !string.IsNullOrWhiteSpace(Poi.MapLink)
                ? Poi.MapLink!
                : $"https://maps.google.com/?q={Poi.Latitude},{Poi.Longitude}";
            StatusText = $"Đã tải chi tiết cho {Poi.Name}.";
        }
        finally
        {
            IsBusy = false;
        }
    }

    [RelayCommand]
    private async Task PlayAsync()
    {
        if (Poi == null) return;
        StatusText = $"Đang phát thuyết minh cho {Poi.Name}.";
        await _narration.HandleAsync(new Announcement(Poi, PoiEventType.Tap, DateTime.UtcNow, LanguageService.Current));
        StatusText = $"Phát xong thuyết minh cho {Poi.Name}.";
    }

    [RelayCommand]
    private void StopAudio()
    {
        _narration.Stop();
        StatusText = "Đã dừng audio hiện tại.";
    }

    [RelayCommand]
    private async Task OpenMapsAsync()
    {
        if (Poi == null) return;
        var url = !string.IsNullOrWhiteSpace(Poi.MapLink)
            ? Poi.MapLink!
            : $"https://maps.google.com/?q={Poi.Latitude},{Poi.Longitude}";

        try
        {
            await Launcher.OpenAsync(new Uri(url));
            StatusText = "Đã mở Google Maps.";
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[PoiDetail/OpenMaps] {ex.Message}");
            StatusText = "Không thể mở Google Maps trên thiết bị hiện tại.";
        }
    }
}
