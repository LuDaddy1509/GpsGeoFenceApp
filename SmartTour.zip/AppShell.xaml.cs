namespace SmartTour.Mobile;

public partial class AppShell : Shell
{
    public AppShell()
    {
        InitializeComponent();
        Routing.RegisterRoute("poidetail", typeof(Pages.PoiDetailPage));
        Routing.RegisterRoute("qrscan", typeof(Pages.QrScanPage));
    }
}
