using System.ComponentModel.DataAnnotations;
using System.Text.Json;
using MapApi.Auth;
using MapApi.Contracts;
using MapApi.Data;
using MapApi.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);
var cs = builder.Configuration.GetConnectionString("Default")
         ?? "Server=.\\SQLEXPRESS;Database=GpsApi;Trusted_Connection=True;Encrypt=True;TrustServerCertificate=True;MultipleActiveResultSets=True";

builder.Services.AddDbContext<AppDb>(opt =>
    opt.UseSqlServer(cs, sql =>
    {
        sql.EnableRetryOnFailure(3, TimeSpan.FromSeconds(5), null);
        sql.CommandTimeout(120);
    }));

builder.Services.AddControllers();
builder.Services.AddProblemDetails();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddCors(opt => opt.AddDefaultPolicy(p => p.AllowAnyHeader().AllowAnyMethod().AllowAnyOrigin()));

var app = builder.Build();
app.UseExceptionHandler();
app.UseStaticFiles();
app.UseCors();
app.UseMiddleware<AdminAuthMiddleware>();
if (app.Environment.IsDevelopment()) { app.UseSwagger(); app.UseSwaggerUI(); }

app.MapGet("/", () => Results.Redirect("/admin/index.html"));
app.MapGet("/health", () => Results.Ok(new { ok = true, time = DateTime.UtcNow, service = "SmartTour API" }));
app.MapControllers();

var pois = app.MapGroup("/api/v1/pois");
pois.MapGet("/", async (string? lang, AppDb db) =>
{
    var items = await db.Pois.AsNoTracking().Where(p => p.IsActive).OrderBy(p => p.Priority).ThenBy(p => p.Name).ToListAsync();
    return Results.Ok(items);
});

pois.MapGet("/sync", async (DateTime? since, AppDb db) =>
{
    var q = db.Pois.AsNoTracking().AsQueryable();
    if (since.HasValue) q = q.Where(p => p.UpdatedAt > since.Value);
    var items = await q.OrderBy(p => p.Priority).ThenBy(p => p.Name).ToListAsync();
    return Results.Ok(new { items, serverTime = DateTime.UtcNow });
});

pois.MapGet("/{id}", async (string id, AppDb db) =>
{
    var poi = await db.Pois.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);
    return poi is null ? Results.NotFound() : Results.Ok(poi);
});

pois.MapGet("/{id}/narration", async (string id, string? lang, string? eventType, AppDb db) =>
{
    var poi = await db.Pois.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id && x.IsActive);
    if (poi is null) return Results.NotFound();
    var language = string.IsNullOrWhiteSpace(lang) ? "vi-VN" : lang.Trim();
    var evt = ParseEventType(eventType);
    var item = await db.PoiNarrations.AsNoTracking().Where(x => x.PoiId == id && x.EventType == evt && x.LanguageTag == language).Select(x => x.NarrationText).FirstOrDefaultAsync();
    if (string.IsNullOrWhiteSpace(item) && language.Contains('-'))
    {
        var primary = language.Split('-')[0];
        item = await db.PoiNarrations.AsNoTracking().Where(x => x.PoiId == id && x.EventType == evt && x.LanguageTag.StartsWith(primary)).Select(x => x.NarrationText).FirstOrDefaultAsync();
    }
    if (string.IsNullOrWhiteSpace(item) && !string.Equals(language, "vi-VN", StringComparison.OrdinalIgnoreCase))
        item = await db.PoiNarrations.AsNoTracking().Where(x => x.PoiId == id && x.EventType == evt && x.LanguageTag == "vi-VN").Select(x => x.NarrationText).FirstOrDefaultAsync();
    item ??= poi.NarrationText;
    return Results.Ok(new { poiId = id, eventType = evt, language, narrationText = item, fallbackUsed = string.IsNullOrWhiteSpace(lang) || !string.Equals(lang, language, StringComparison.OrdinalIgnoreCase) });
});

var admin = app.MapGroup("/api/v1/admin");
admin.MapGet("/dashboard", async (AppDb db) =>
{
    var topPois = await db.PlaybackLogs.AsNoTracking()
        .GroupBy(x => new { x.PoiId, Name = x.Poi != null ? x.Poi.Name : x.PoiId })
        .Select(g => new { poiId = g.Key.PoiId, poiName = g.Key.Name, playCount = g.Count(), avgSeconds = Math.Round(g.Average(x => (double?)x.DurationListened ?? 0), 1), lastPlayed = g.Max(x => x.PlayedAt) })
        .OrderByDescending(x => x.playCount).Take(10).ToListAsync();

    var topLanguage = await db.PlaybackLogs.AsNoTracking().GroupBy(x => x.Language).OrderByDescending(g => g.Count()).Select(g => g.Key).FirstOrDefaultAsync();
    return Results.Ok(new
    {
        totalPois = await db.Pois.CountAsync(),
        activePois = await db.Pois.CountAsync(x => x.IsActive),
        totalPlays = await db.PlaybackLogs.CountAsync(),
        uniqueDevices = await db.PlaybackLogs.Select(x => x.DeviceId).Distinct().CountAsync(),
        qrFallbackCount = await db.PlaybackLogs.CountAsync(x => x.TriggerType == "QR" || x.Source == "qr-fallback"),
        topLanguage,
        topPois = topPois.Select(x => new { x.poiId, x.poiName, x.playCount, x.avgSeconds, lastPlayedLocal = x.lastPlayed.ToLocalTime().ToString("dd/MM HH:mm") })
    });
});

admin.MapGet("/system-info", async (AppDb db) => Results.Ok(new
{
    platform = ".NET + ASP.NET Core + EF Core",
    database = db.Database.ProviderName,
    serverTimeUtc = DateTime.UtcNow,
    features = new[] { "offline-first", "qr-fallback", "dashboard", "poi-management", "seed-demo", "multilingual-narration" }
}));

admin.MapGet("/pois", async (AppDb db) =>
{
    var items = await db.Pois.AsNoTracking().OrderBy(x => x.Priority).ThenBy(x => x.Name).ToListAsync();
    return Results.Ok(items);
});

admin.MapGet("/pois/{id}", async (string id, AppDb db) =>
{
    var poi = await db.Pois.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);
    return poi is null ? Results.NotFound() : Results.Ok(poi);
});

admin.MapPost("/pois", async ([FromBody] PoiUpsertRequest req, AppDb db) =>
{
    var errors = Validate(req);
    if (errors.Count > 0) return Results.ValidationProblem(errors);
    var poi = new Poi
    {
        Id = string.IsNullOrWhiteSpace(req.Id) ? Guid.NewGuid().ToString("N") : req.Id!,
        Name = req.Name.Trim(), Description = req.Description.Trim(), Latitude = req.Latitude, Longitude = req.Longitude, RadiusMeters = req.RadiusMeters,
        NearRadiusMeters = req.NearRadiusMeters, DebounceSeconds = req.DebounceSeconds, CooldownSeconds = req.CooldownSeconds, Priority = req.Priority,
        AudioUrl = req.AudioUrl, ImageUrl = req.ImageUrl, MapLink = req.MapLink, IsActive = req.IsActive, UpdatedAt = DateTime.UtcNow
    };
    db.Pois.Add(poi);
    await db.SaveChangesAsync();
    return Results.Created($"/api/v1/pois/{poi.Id}", poi);
});

admin.MapPut("/pois/{id}", async (string id, [FromBody] PoiUpsertRequest req, AppDb db) =>
{
    var errors = Validate(req);
    if (errors.Count > 0) return Results.ValidationProblem(errors);
    var e = await db.Pois.FirstOrDefaultAsync(x => x.Id == id);
    if (e is null) return Results.NotFound();
    e.Name = req.Name.Trim(); e.Description = req.Description.Trim(); e.Latitude = req.Latitude; e.Longitude = req.Longitude; e.RadiusMeters = req.RadiusMeters;
    e.NearRadiusMeters = req.NearRadiusMeters; e.DebounceSeconds = req.DebounceSeconds; e.CooldownSeconds = req.CooldownSeconds; e.Priority = req.Priority; e.AudioUrl = req.AudioUrl; e.ImageUrl = req.ImageUrl; e.MapLink = req.MapLink; e.IsActive = req.IsActive; e.UpdatedAt = DateTime.UtcNow;
    await db.SaveChangesAsync();
    return Results.Ok(e);
});

admin.MapDelete("/pois/{id}", async (string id, AppDb db) =>
{
    var e = await db.Pois.FirstOrDefaultAsync(x => x.Id == id);
    if (e is null) return Results.NotFound();
    db.Pois.Remove(e);
    await db.SaveChangesAsync();
    return Results.Ok(new { deleted = id });
});

admin.MapPost("/seed-demo", async (AppDb db, IWebHostEnvironment env) =>
{
    var seedPath = Path.Combine(env.ContentRootPath, "Seed", "sample-pois.json");
    if (!File.Exists(seedPath))
        return Results.NotFound(new { error = "Seed file not found", seedPath });

    var json = await File.ReadAllTextAsync(seedPath);
    var items = JsonSerializer.Deserialize<List<PoiUpsertRequest>>(json, new JsonSerializerOptions(JsonSerializerDefaults.Web)) ?? new();
    var now = DateTime.UtcNow;
    var inserted = 0;
    var updated = 0;

    foreach (var req in items)
    {
        var errors = Validate(req);
        if (errors.Count > 0) continue;

        var id = string.IsNullOrWhiteSpace(req.Id) ? Guid.NewGuid().ToString("N") : req.Id!;
        var entity = await db.Pois.FirstOrDefaultAsync(x => x.Id == id);
        if (entity == null)
        {
            entity = new Poi { Id = id };
            db.Pois.Add(entity);
            inserted++;
        }
        else
        {
            updated++;
        }

        entity.Name = req.Name.Trim();
        entity.Description = req.Description.Trim();
        entity.Latitude = req.Latitude;
        entity.Longitude = req.Longitude;
        entity.RadiusMeters = req.RadiusMeters;
        entity.NearRadiusMeters = req.NearRadiusMeters;
        entity.DebounceSeconds = req.DebounceSeconds;
        entity.CooldownSeconds = req.CooldownSeconds;
        entity.Priority = req.Priority;
        entity.ImageUrl = req.ImageUrl;
        entity.AudioUrl = req.AudioUrl;
        entity.MapLink = req.MapLink;
        entity.IsActive = req.IsActive;
        entity.NarrationText ??= $"Chào mừng bạn đến với {entity.Name}. Đây là nội dung thuyết minh mẫu phục vụ demo đồ án SmartTour.";
        entity.UpdatedAt = now;
    }

    await db.SaveChangesAsync();
    return Results.Ok(new { inserted, updated, total = await db.Pois.CountAsync() });
});

admin.MapGet("/export", async (AppDb db) =>
{
    var poisData = await db.Pois.AsNoTracking().OrderBy(x => x.Priority).ThenBy(x => x.Name).ToListAsync();
    var stats = await db.PlaybackLogs.AsNoTracking().GroupBy(x => x.PoiId).Select(g => new { poiId = g.Key, playCount = g.Count() }).ToListAsync();
    return Results.Ok(new { exportedAt = DateTime.UtcNow, pois = poisData, playbackStats = stats });
});

var logs = app.MapGroup("/api/v1/playback");
logs.MapPost("/", async ([FromBody] PlaybackLogRequest req, AppDb db) =>
{
    var errors = Validate(req);
    if (errors.Count > 0) return Results.ValidationProblem(errors);
    if (!await db.Pois.AnyAsync(p => p.Id == req.PoiId)) return Results.BadRequest(new { error = "POI not found" });
    var log = new PlaybackLog
    {
        DeviceId = req.DeviceId, PoiId = req.PoiId, TriggerType = req.TriggerType.ToUpperInvariant(),
        DurationListened = req.DurationListened, IsSuccess = req.IsSuccess, PlayedAt = DateTime.UtcNow,
        Language = string.IsNullOrWhiteSpace(req.Language) ? "vi-VN" : req.Language!,
        Source = string.IsNullOrWhiteSpace(req.Source) ? "mobile" : req.Source!
    };
    db.PlaybackLogs.Add(log);
    await db.SaveChangesAsync();
    return Results.Ok(new { log.Id, log.PlayedAt });
});

logs.MapGet("/stats", async (AppDb db) =>
{
    var stats = await db.PlaybackLogs.AsNoTracking().GroupBy(l => l.PoiId).Select(g => new { poiId = g.Key, playCount = g.Count(), avgSeconds = g.Average(x => (double?)x.DurationListened ?? 0), lastPlayed = g.Max(x => x.PlayedAt) }).OrderByDescending(x => x.playCount).Take(20).ToListAsync();
    return Results.Ok(stats);
});

app.Run();

static Dictionary<string, string[]> Validate<T>(T model)
{
    var context = new ValidationContext(model!);
    var results = new List<ValidationResult>();
    Validator.TryValidateObject(model!, context, results, true);
    return results
        .GroupBy(r => r.MemberNames.FirstOrDefault() ?? string.Empty)
        .ToDictionary(g => g.Key, g => g.Select(r => r.ErrorMessage ?? "Invalid").ToArray());
}

static byte ParseEventType(string? s) => (s ?? string.Empty).Trim().ToLowerInvariant() switch
{
    "enter" => 0,
    "near" => 1,
    "tap" => 2,
    _ => 0
};
