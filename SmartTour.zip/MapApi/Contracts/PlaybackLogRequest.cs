using System.ComponentModel.DataAnnotations;

namespace MapApi.Contracts;

public sealed class PlaybackLogRequest
{
    [Required, StringLength(64)] public string DeviceId { get; set; } = string.Empty;
    [Required, StringLength(64)] public string PoiId { get; set; } = string.Empty;
    [Required, StringLength(32)] public string TriggerType { get; set; } = string.Empty;
    [Range(0, 7200)] public int? DurationListened { get; set; }
    public bool IsSuccess { get; set; } = true;
    [StringLength(16)] public string? Language { get; set; }
    [StringLength(32)] public string? Source { get; set; }
}
