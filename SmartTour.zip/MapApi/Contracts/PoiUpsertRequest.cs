using System.ComponentModel.DataAnnotations;

namespace MapApi.Contracts;

public sealed class PoiUpsertRequest
{
    public string? Id { get; set; }
    [Required, StringLength(200, MinimumLength = 2)] public string Name { get; set; } = string.Empty;
    [StringLength(2000)] public string Description { get; set; } = string.Empty;
    [Range(-90,90)] public double Latitude { get; set; }
    [Range(-180,180)] public double Longitude { get; set; }
    [Range(30,1000)] public int RadiusMeters { get; set; } = 120;
    [Range(50,2000)] public int NearRadiusMeters { get; set; } = 220;
    [Range(0,120)] public int DebounceSeconds { get; set; } = 3;
    [Range(0,600)] public int CooldownSeconds { get; set; } = 30;
    [Range(1,999)] public int Priority { get; set; } = 1;
    [StringLength(1000)] public string? ImageUrl { get; set; }
    [StringLength(1000)] public string? AudioUrl { get; set; }
    [StringLength(1000)] public string? MapLink { get; set; }
    public bool IsActive { get; set; } = true;
}
