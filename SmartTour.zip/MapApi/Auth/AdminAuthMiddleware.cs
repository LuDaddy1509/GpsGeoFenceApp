using System.Text;

namespace MapApi.Auth;

public sealed class AdminAuthMiddleware
{
    private readonly RequestDelegate _next;
    private readonly IConfiguration _config;

    public AdminAuthMiddleware(RequestDelegate next, IConfiguration config)
    {
        _next = next;
        _config = config;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        if (!context.Request.Path.StartsWithSegments("/api/v1/admin") && !context.Request.Path.StartsWithSegments("/admin"))
        {
            await _next(context);
            return;
        }

        var username = _config["AdminAuth:Username"] ?? "admin";
        var password = _config["AdminAuth:Password"] ?? "P@ssw0rd!";
        var header = context.Request.Headers.Authorization.ToString();
        if (header.StartsWith("Basic ", StringComparison.OrdinalIgnoreCase))
        {
            try
            {
                var raw = Encoding.UTF8.GetString(Convert.FromBase64String(header[6..]));
                var parts = raw.Split(':', 2);
                if (parts.Length == 2 && parts[0] == username && parts[1] == password)
                {
                    await _next(context);
                    return;
                }
            }
            catch { }
        }

        context.Response.Headers.WWWAuthenticate = "Basic realm=\"SmartTour Admin\"";
        context.Response.StatusCode = StatusCodes.Status401Unauthorized;
        await context.Response.WriteAsJsonAsync(new { error = "Unauthorized admin access" });
    }
}
